INSERT INTO `config` VALUES('TMP_DIR',0,'','Directory for temporary files');
