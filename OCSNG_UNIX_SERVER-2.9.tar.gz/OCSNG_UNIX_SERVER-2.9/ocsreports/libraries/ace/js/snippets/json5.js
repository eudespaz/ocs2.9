
;                (function() {
                    window.require(["ace/snippets/json5"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            